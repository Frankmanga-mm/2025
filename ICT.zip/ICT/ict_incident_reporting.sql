-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 05, 2025 at 03:42 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ict_incident_reporting`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_edited` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `last_edited`) VALUES
(4, 'software', '2025-03-11 20:18:52', '2025-04-05 05:19:39'),
(5, 'Graphicssss', '2025-03-11 20:32:18', '2025-04-05 11:12:24'),
(7, 'meza', '2025-04-05 11:18:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `comment` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ticket_number` (`ticket_number`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `ticket_number`, `user_id`, `comment`, `created_at`) VALUES
(1, 'TKT-67D9D32E47C03', 12, 'Tafadhali , elezea tatizo ni nini', '2025-04-05 14:28:49'),
(5, 'TKT-67D9D32E47C03', 1, 'computer ina sumbua', '2025-04-05 14:59:42'),
(6, 'TKT-67D9D32E47C03', 1, 'computer ina sumbua', '2025-04-05 15:01:18'),
(16, 'TKT-67D9D32E47C03', 12, 'hello', '2025-04-05 15:12:33'),
(17, 'TKT-67D9D32E47C03', 1, 'nam katibu', '2025-04-05 15:13:09'),
(18, 'TKT-67D9D32E47C03', 1, 'unasemaje ?', '2025-04-05 15:13:47'),
(19, 'TKT-67D9D32E47C03', 12, 'sina usemi , ticket inafanyiwa kazi', '2025-04-05 15:16:31'),
(20, 'TKT-67D9D32E47C03', 12, 'sina usemi , ticket inafanyiwa kazi', '2025-04-05 15:17:52'),
(21, 'TKT-67D9D32E47C03', 12, 'sina usemi , ticket inafanyiwa kazi', '2025-04-05 15:22:41'),
(22, 'TKT-67D9D32E47C03', 12, 'ssawa', '2025-04-05 15:23:30'),
(23, 'TKT-67D9D2120AD1F', 1, 'oya', '2025-04-05 15:24:25'),
(24, 'TKT-67D9D2120AD1F', 12, 'nam kaka', '2025-04-05 15:26:15'),
(25, 'TKT-67D9D2120AD1F', 1, 'mmekaa kimya', '2025-04-05 15:33:34');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `created_at`) VALUES
(3, 'Procurements', '2025-02-17 12:27:45'),
(4, 'As', '2025-02-17 12:27:45'),
(6, 'literatures', '2025-02-17 12:54:07'),
(11, 'sasa', '2025-04-05 10:34:39');

-- --------------------------------------------------------

--
-- Table structure for table `priorities`
--

DROP TABLE IF EXISTS `priorities`;
CREATE TABLE IF NOT EXISTS `priorities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_edited` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `priorities`
--

INSERT INTO `priorities` (`id`, `name`, `created_at`, `last_edited`) VALUES
(1, 'High', '2025-03-11 20:27:30', '2025-04-05 11:33:13'),
(3, 'Medium', '2025-04-05 11:33:48', NULL),
(4, 'Low', '2025-04-05 11:34:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `priority` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `ticket_number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT 'Open',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `screenshot` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reported_by` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `reported_to` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `last_updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `user_id`, `priority`, `ticket_number`, `description`, `category`, `status`, `created_at`, `screenshot`, `reported_by`, `reported_to`, `last_updated`) VALUES
(1, 12, 'Highs', 'TKT-67D0B218483E0', 'Something is wrong with my pc', 'softwaresss', 'Closed', '2025-03-11 21:58:48', '', 'mlelwaimma99@gmail.com', 'mlelwaimma96@gmail.com', NULL),
(24, 12, 'Highs', 'TKT-67D9D2120AD1F', 'bb', 'softwaresss', 'Open', '2025-03-18 20:05:38', '../assets/ticketuploads/1742328338_1000071952.jpg', 'mlelwaimma99@gmail.com', 'mlelwaimma96@gmail.com', NULL),
(25, 12, 'Highs', 'TKT-67D9D299E6461', 'rr', 'Graphics', 'Open', '2025-03-18 20:07:53', '../assets/ticketuploads/1742328473_1000071952.jpg', 'mlelwaimma99@gmail.com', 'mlelwaimma96@gmail.com', NULL),
(26, 12, 'Low', 'TKT-67D9D32E47C03', 'dd', 'Graphics', 'Open', '2025-03-18 20:10:22', '../assets/ticketuploads/1742328622_1000116911 (1).jpg', 'mlelwaimma99@gmail.com', 'mlelwaimma96@gmail.com', NULL),
(27, 1, 'Medium', 'TKT-67F14DC51A7A2', 'Naomba kuufngiwa camera ofisini kwangu', 'meza', 'Open', '2025-04-05 15:35:33', '', 'mlelwaimma99@gmail.com', 'mlelwaimma96@gmail.com', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_statuses`
--

DROP TABLE IF EXISTS `ticket_statuses`;
CREATE TABLE IF NOT EXISTS `ticket_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_edited` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_statuses`
--

INSERT INTO `ticket_statuses` (`id`, `name`, `created_at`, `last_edited`) VALUES
(3, 'Pending', '2025-03-11 20:52:07', NULL),
(4, 'Closed', '2025-03-11 20:54:08', '2025-03-11 20:54:28'),
(5, 'In progress', '2025-04-05 11:22:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `middle_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('user','admin','Technician') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `department_id` int NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_general_ci DEFAULT 'Inactive',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `department_id` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `email`, `password`, `phone`, `role`, `department_id`, `status`, `created_at`) VALUES
(1, 'imma', 'erick', 'mlelwa', 'mlelwaimma99@gmail.com', '$2y$10$8su1DZXlDV/W6afx32aWjO9bhJHkEPcB7qRLH/qd3Jpv4ypNxqU2u', '+888', 'user', 4, 'Active', '2025-02-17 12:28:07'),
(12, 'Nicky', 'Erhards', 'Mlelwa', 'mlelwaimma96@gmail.com', '$2y$10$/jVatzHkgQru.jXOqaAGhOXhd5sO1Zliuj9PHfPMD1rMUEWkXNQJq', '1234456', 'admin', 4, 'Active', '2025-03-11 19:43:19'),
(16, 'sasa', 'sasa', 'sasa', 'mlelwaimma66@gmail.com', '$2y$10$8su1DZXlDV/W6afx32aWjO9bhJHkEPcB7qRLH/qd3Jpv4ypNxqU2u', '23', 'Technician', 3, 'Active', '2025-04-05 09:39:09');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
