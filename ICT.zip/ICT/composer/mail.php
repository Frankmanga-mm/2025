<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Form</title>
</head>
<body>
    <h2>Send Email</h2>
    <form method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea><br>
        <input type="submit" name="submit" value="Send Email">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
        require 'path/to/PHPMailer-master/src/PHPMailer.php';
        require 'path/to/PHPMailer-master/src/SMTP.php';
        require 'path/to/PHPMailer-master/src/Exception.php';

        $email = $_POST['email'];
        $message = $_POST['message'];

        $mail = new PHPMailer(true); // Set true for exceptions

        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_OFF; // Set to SMTP::DEBUG_SERVER for debugging
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.example.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'your-email@example.com'; // SMTP username
            $mail->Password = 'your-smtp-password'; // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption, `PHPMailer::ENCRYPTION_SMTPS` also accepted
            $mail->Port = 587; // TCP port to connect to

            //Recipients
            $mail->setFrom('your-email@example.com', 'Your Name');
            $mail->addAddress($email); // Add recipient email

            //Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'Subject Here';
            $mail->Body = $message;

            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
    ?>
</body>
</html>
