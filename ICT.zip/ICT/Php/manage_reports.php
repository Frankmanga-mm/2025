<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';
include "connection.php";

// Ensure admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$admin_id = $_SESSION['user_id'];

// Fetch all incidents
$incidents_query = "SELECT * FROM incidents";
$incidents_result = mysqli_query($conn, $incidents_query);
if (!$incidents_result) {
    die("Error fetching incidents: " . mysqli_error($conn));
}

// Fetch ICT department ID
$ict_department_query = "SELECT id FROM departments WHERE name = 'ICT'";
$ict_department_result = mysqli_query($conn, $ict_department_query);
$ict_department = mysqli_fetch_assoc($ict_department_result);
$ict_department_id = $ict_department['id'];

// Fetch all ICT technicians
$technicians_query = "SELECT id, email FROM users WHERE department_id = '$ict_department_id' AND role = 'Technician'";
$technicians_result = mysqli_query($conn, $technicians_query);

// Function to send email
function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mangafrank20@gmail.com'; // Change to your email
        $mail->Password = 'zbhx zgjk plhg lgzo'; // Change to your app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('mangafrank20@gmail.com', 'ICT-Incident-Reporting-System');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        return $mail->send();
    } catch (Exception $e) {
        echo "Mailer Error: " . $mail->ErrorInfo;
        return false;
    }
}

// Handle incident referral
if (isset($_POST['refer_incident'])) {
    $incident_id = $_POST['incident_id'];
    $technician_id = $_POST['technician_id'];
    
    // Fetch incident details
    $incident_query = "SELECT ticket_number, reported_by FROM incidents WHERE id='$incident_id'";
    $incident_result = mysqli_query($conn, $incident_query);
    $incident = mysqli_fetch_assoc($incident_result);
    $ticket_number = $incident['ticket_number'];
    $reported_by_email = $incident['reported_by'];

    // Fetch technician email
    $tech_query = "SELECT email FROM users WHERE id = '$technician_id'";
    $tech_result = mysqli_query($conn, $tech_query);
    $technician = mysqli_fetch_assoc($tech_result);
    $technician_email = $technician['email'];

    // Update status and assign technician
    $update_query = "UPDATE incidents SET assigned_technician='$technician_id', status='In Progress' WHERE id='$incident_id'";
    
    if (mysqli_query($conn, $update_query)) {
        // Prepare email messages
        $technician_message = "
            <p>Hello,</p>
            <p>A new incident (Ticket #$ticket_number) has been assigned to you.</p>
            <p>Please log in to the system to take action.</p>
        ";

        $reporter_message = "
            <p>Hello,</p>
            <p>Your incident (Ticket #$ticket_number) has been referred for consideration.</p>
            <p>Our team is working on it.</p>
        ";

        // Send emails
        $tech_email_sent = sendEmail($technician_email, "New Incident Assigned", $technician_message);
        $reporter_email_sent = sendEmail($reported_by_email, "Incident Referred", $reporter_message);

        // Check if emails were sent successfully
        if ($tech_email_sent && $reporter_email_sent) {
            header("Location: manage_reports.php");
            exit;
        } else {
            echo "<p style='color:red;'>Failed to send email notifications.</p>";
        }
    } else {
        echo "<p style='color:red;'>Error updating incident status: " . mysqli_error($conn) . "</p>";
    }
}

// Handle incident resolution
if (isset($_POST['resolve_incident'])) {
    $incident_id = $_POST['incident_id'];
    $incident_query = "SELECT ticket_number, reported_by FROM incidents WHERE id='$incident_id'";
    $incident_result = mysqli_query($conn, $incident_query);
    $incident = mysqli_fetch_assoc($incident_result);
    $ticket_number = $incident['ticket_number'];
    $reported_by_email = $incident['reported_by'];
    
    $update_query = "UPDATE incidents SET status='Resolved' WHERE id='$incident_id'";
    if (mysqli_query($conn, $update_query)) {
        $resolution_message = "
            <p>Hello,</p>
            <p>Your incident (Ticket #$ticket_number) has been resolved.</p>
            <p>Thank you for reporting the issue.</p>
        ";

        sendEmail($reported_by_email, "Incident Resolved", $resolution_message);
    }
    header("Location: manage_reports.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h3 class="text-center">Incident Management</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Ticket #</th>
                    <th>Reported By</th>
                    <th>Reported For</th>
                    <th>Category</th>
                    <th>Priority</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($incidents_result)) { ?>
                    <tr>
                        <td><?= $row['ticket_number'] ?></td>
                        <td><?= $row['reported_by'] ?></td>
                        <td><?= $row['reported_for'] ?></td>
                        <td><?= $row['category'] ?></td>
                        <td><?= $row['priority'] ?></td>
                        <td><?= $row['description'] ?></td>
                        <td><?= $row['status'] ?></td>
                        <td>
                            <form action="" method="POST">
                                <input type="hidden" name="incident_id" value="<?= $row['id'] ?>">
                                <select name="technician_id" required>
                                    <option value="">Select Technician</option>
                                    <?php while ($tech = mysqli_fetch_assoc($technicians_result)) { ?>
                                        <option value="<?= $tech['id'] ?>"> <?= $tech['email'] ?> </option>
                                    <?php } ?>
                                </select>
                                <button type="submit" name="refer_incident" class="btn btn-warning btn-sm">Refer</button>
                            </form>
                            <form action="" method="POST">
                                <input type="hidden" name="incident_id" value="<?= $row['id'] ?>">
                                <button type="submit" name="resolve_incident" class="btn btn-success btn-sm">Resolve</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>



