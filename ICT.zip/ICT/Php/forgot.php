<?php
session_start();
require_once 'connection.php'; // Include database connection
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

$message = ""; // Variable to store messages

if (isset($_POST['reset'])) {
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    
    // Check if email exists in the database and fetch first name
    $query = "SELECT first_name FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $firstName = $row['first_name']; // Get the first name
        
        // Send email with direct reset link
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mlelwaimma99@gmail.com';
            $mail->Password = 'haxu ddpx szus blnx';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            
            $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($email);
            
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body = "
                Dear <strong>$firstName</strong>,<br><br>
                We have received your request to reset your password.<br>
                Click the link below to create a new password:<br><br>
                <a href='http://localhost/ICT/Php/create_password.php?email=" . urlencode($email) . "'>
                Click here to create your new password</a><br><br>
                If you did not request a password reset, please ignore this email.<br><br>
                Best regards,<br>
                ICT-Incident-Reporting-System Team
            ";

            $mail->send();
            $message = "<p style='color: green;'>A reset link has been sent to your email.</p>";

            // Update the password column to be empty in the users table
            $updateQuery = "UPDATE users SET password='' WHERE email='$email'";
            if (mysqli_query($conn, $updateQuery)) {
                // Optionally, you can log this action or notify the user
            } else {
                $message = "<p style='color: red;'>Failed to update password in the database.</p>";
            }

        } catch (Exception $e) {
            $message = "<p style='color: red;'>Email sending failed: " . $mail->ErrorInfo . "</p>";
        }
    } else {
        $message = "<p style='color: red;'>Email not found!</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Enter Your Email</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container { width: 40%; margin: 100px auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); text-align: center; }
        input[type=email], button { width: 100%; padding: 10px; margin: 10px 0; border-radius: 5px; border: 1px solid #ccc; }
        button { background: #28a745; color: white; border: none; cursor: pointer; }
        button:hover { background: #218838; }
        .message { margin-top: 10px; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Enter Your Email</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit" name="reset">Send Reset Link</button>
        </form>
        <div class="message"><?php echo $message; ?></div> <!-- Message appears here -->
    </div>
</body>
</html>