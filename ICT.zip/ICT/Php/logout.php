<?php
session_start();
include "connection.php";

// Unset all session variables
$_SESSION = array();

// If it's desired to kill the session, also delete the session cookie.
// This will remove the session from the user's browser.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finally, destroy the session
session_destroy();

// Redirect to the index page
header("Location: ../index.php");
exit;
?>
