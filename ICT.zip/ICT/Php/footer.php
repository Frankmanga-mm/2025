<!-- includes/footer.php -->
<footer>
    <p>Incident Reporting System @2025</p>
</footer>
<!-- Scripts -->
<script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        function toggleDropdown(event, id) {
            event.preventDefault();
            var dropdown = document.getElementById(id);
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>