<?php
require_once 'connection.php';


session_start();
if ($_SESSION['role'] !== 'user' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit;
}


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

$user_id = $_SESSION['user_id'];
$email = $_SESSION['user_email'];
$first_name = $_SESSION['user_name'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Delete the user's password from the database
    $query = "UPDATE users SET password=NULL WHERE id=? AND email=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $user_id, $email);

    if ($stmt->execute()) {
        // Logout user
        session_destroy();


        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mlelwaimma99@gmail.com'; // SMTP username
            $mail->Password = 'haxu ddpx szus blnx'; // Use App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Email settings
            $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($email);

            // Email content
            $mail->isHTML(true);
            $mail->Subject = 'Create Your Password';
            $mail->Body = "Dear $first_name,<br><br>We received a request that you want to change your password. 
                           Please click the link below to create a new password:<br><br>
                           <a href='http://localhost/ICT/Php/create_password.php?email=$email'>Click here to create your password</a><br><br>
                           Regards,<br>ICT Incident Reporting System";

            // Send email
            $mail->send();

            // Redirect to login page
            header("Location: ../index.php");
            exit;

        } catch (Exception $e) {
            echo "<p style='color: red;'>Email could not be sent. Error: " . $mail->ErrorInfo . "</p>";
        }

    } else {
        echo "<p style='color: red;'>Error updating password: " . $conn->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
   
    <link rel="stylesheet" href="userstyles.css">
    <style>


.container {
    text-align: center;
    margin-top: 150px;
    padding: 30px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 40%;
    margin-left: auto;
    margin-right: auto;
}

h2 {
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
    font-weight: bold;
}

.btn-danger {
    display: inline-block;
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    background: linear-gradient(135deg, #ff4b5c, #ff6b81);
    border: none;
    border-radius: 25px;
    padding: 12px 30px;
    cursor: pointer;
    transition: 0.3s ease-in-out;
    text-transform: uppercase;
    letter-spacing: 1px;
    box-shadow: 0 4px 6px rgba(255, 75, 92, 0.3);
}

.btn-danger:hover {
    background: linear-gradient(135deg, #ff6b81, #ff4b5c);
    transform: scale(1.05);
    box-shadow: 0 6px 12px rgba(255, 75, 92, 0.4);
}



    </style>
</head>
<body>




<?php include 'userheader.php'; ?>
<?php include 'usersidebar.php'; ?>


    <div class="container">
        <h2>Change Password</h2>
        <form method="POST">
            <button type="submit" class="btn btn-danger">Change Password</button>
        </form>
    </div>
</body>
</html>
