<?php

session_start();

// Redirect if the role is not 'admin' or the username is empty
if ($_SESSION['role'] !== 'admin' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit; // Ensure script stops execution after redirection
}

require_once 'connection.php'; // Database connection

// Function to redirect with a message
function redirectWithMessage($msg, $type = 'success') {
    header("Location: manage_priority.php?msg=" . urlencode($msg) . "&type=" . $type);
    exit();
}

// Pagination variables
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 5; // Default limit set to 5
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Default page
$offset = ($page - 1) * $limit;

// Fetch priorities with pagination
$query = "SELECT * FROM priorities ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Error fetching priorities: " . mysqli_error($conn));
}

// Fetch total number of priorities for pagination
$total_query = "SELECT COUNT(*) as total FROM priorities";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_priorities = $total_row['total'];
$total_pages = ceil($total_priorities / $limit);

// Handle Add Priority
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_priority'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $query = "INSERT INTO priorities (name) VALUES ('$name')";
    if (mysqli_query($conn, $query)) {
        redirectWithMessage("Priority added successfully!", "success");
    } else {
        redirectWithMessage("Error: " . mysqli_error($conn), "error");
    }
}

// Handle Edit Priority
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_priority'])) {
    $id = intval($_POST['priority_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $query = "UPDATE priorities SET name='$name', last_edited=NOW() WHERE id='$id'";
    if (mysqli_query($conn, $query)) {
        redirectWithMessage("Priority updated successfully!", "success");
    } else {
        redirectWithMessage("Error updating priority: " . mysqli_error($conn), "error");
    }
}

// Handle Delete Priority
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_priority'])) {
    $id = intval($_POST['priority_id']);
    $query = "DELETE FROM priorities WHERE id='$id'";
    if (mysqli_query($conn, $query)) {
        redirectWithMessage("Priority deleted successfully!", "success");
    } else {
        redirectWithMessage("Error deleting priority: " . mysqli_error($conn), "error");
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Priorities</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        
        .container {
            margin-top: 8%;
        }
    </style>
</head>
<body>

<?php if (isset($_GET['msg'])): ?>
    <div id="messageBox" class="alert alert-<?= $_GET['type'] == 'success' ? 'success' : 'danger' ?> text-center">
        <?= htmlspecialchars($_GET['msg']) ?>
    </div>

    <script>
        setTimeout(function() {
            document.getElementById("messageBox").style.display = "none"; // Hide message
            window.location.href = "manage_priority.php"; // Refresh once
        }, 2000);
    </script>
<?php endif; ?>

<?php include 'adminheader.php'; ?>
<?php include 'adminsidebar.php'; ?>

<div class="container">

<h2 class="text-center mb-4">Manage Ticket Priorities</h2>
    <button type="button" class="btn btn-success mb-3" data-toggle="modal" data-target="#addPriorityModal">Add Priority</button>

    <input type="text" id="search" class="form-control mb-3" placeholder="Search priorities...">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Priority Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="priorityTable">
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm edit-btn" data-id="<?= $row['id'] ?>" data-name="<?= htmlspecialchars($row['name']) ?>">Edit</button>
                        
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this priority?');">
                            <input type="hidden" name="priority_id" value="<?= $row['id'] ?>">
                            <button type="submit" name="delete_priority" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    
</div>

<!-- Add Priority Modal -->
<div class="modal fade" id="addPriorityModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Priority</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="text" name="name" class="form-control" required placeholder="Priority Name">
                </div>
                <div class="modal-footer">
                    <button type="submit" name="add_priority" class="btn btn-success">Add</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Priority Modal -->
<div class="modal fade" id="editPriorityModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Priority</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="priority_id" id="edit_priority_id">
                    <input type="text" name="name" id="edit_priority_name" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="edit_priority" class="btn btn-warning">Update</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    $("#search").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#priorityTable tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });

    $(".edit-btn").click(function () {
        var id = $(this).data("id");
        var name = $(this).data("name");
        $("#edit_priority_id").val(id);
        $("#edit_priority_name").val(name);
        $("#editPriorityModal").modal("show");
    });
});
</script>



<script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        function toggleDropdown(event, id) {
            event.preventDefault();
            var dropdown = document.getElementById(id);
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
</body>
</html>