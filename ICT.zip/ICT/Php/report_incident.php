<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

include "connection.php";

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details and department name
$user_query = "SELECT u.email, u.department_id, d.name AS department_name 
               FROM users u
               JOIN departments d ON u.department_id = d.id
               WHERE u.id = '$user_id'";

$user_result = mysqli_query($conn, $user_query);

if (!$user_result) {
    die('Error fetching user details: ' . mysqli_error($conn));
}

$user = mysqli_fetch_assoc($user_result);

if (!$user) {
    die("Error: No user found.");
}

$reported_by = $user['email'];
$user_department_id = $user['department_id'];
$department_name = $user['department_name'];

// Get ICT department ID
$ict_department_query = "SELECT id FROM departments WHERE name = 'ICT' LIMIT 1";
$ict_department_result = mysqli_query($conn, $ict_department_query);
$ict_department = mysqli_fetch_assoc($ict_department_result);
$ict_department_id = $ict_department['id'] ?? null;

if (!$ict_department_id) {
    die("Error: ICT department not found.");
}

// Function to generate ticket number
function generateTicketNumber() {
    $letters = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 2);
    $numbers = str_pad(mt_rand(0, 9999), 4, '0', STR_PAD_LEFT);
    return $letters . $numbers;
}

// Handle incident reporting
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reported_for = mysqli_real_escape_string($conn, $_POST['reported_for'] ?? $reported_by);
    $priority = mysqli_real_escape_string($conn, $_POST['priority']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $created_at = date('Y-m-d H:i:s');
    $ticket_number = generateTicketNumber();

    // Handle screenshot upload
    $screenshot = NULL;
    if (!empty($_FILES['screenshot']['name'])) {
        $target_dir = "../assets/uploads/";
        $file_name = time() . "_" . basename($_FILES["screenshot"]["name"]);
        $target_file = $target_dir . $file_name;

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES["screenshot"]["tmp_name"], $target_file)) {
            $screenshot = $target_file;
        }
    }

    // Insert incident into the database
    $insert_query = "INSERT INTO incidents (user_id, department_id, priority, ticket_number, description, category, status, created_at, screenshot, reported_by, reported_for, reported_to) 
                     VALUES ('$user_id', '$ict_department_id', '$priority', '$ticket_number', '$description', '$category', 'Pending', '$created_at', '$screenshot', '$reported_by', '$reported_for', NULL)";

    if (mysqli_query($conn, $insert_query)) {
        // Fetch ICT Department Admin email
        $admin_query = "SELECT email FROM users WHERE role = 'admin' AND department_id = '$ict_department_id' LIMIT 1";
        $admin_result = mysqli_query($conn, $admin_query);
        $admin = mysqli_fetch_assoc($admin_result);
        $admin_email = $admin['email'] ?? null;

        if ($admin_email) {
            $subject = "New Incident Reported - Ticket: $ticket_number";
            $message = "Greetings Admin, <br><br>A new incident has been reported by $reported_by. The details are as follows:<br><br>
                        <strong>Ticket Number:</strong> $ticket_number<br>
                        <strong>Category:</strong> $category<br>
                        <strong>Priority:</strong> $priority<br>
                        <strong>Description:</strong> $description<br>
                        <strong>Reported At:</strong> $created_at<br>
                        <strong>Reported For:</strong> $reported_for<br><br>
                        Please take necessary action.<br><br>Best regards,<br>ICT Incident Reporting System";

            // Send email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'mlelwaimma99@gmail.com';
                $mail->Password = 'haxu ddpx szus blnx';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('mangafrank20@gmail.com', 'ICT-Incident-Reporting-System');
                $mail->addAddress($admin_email);

                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $message;

                $mail->send();
            } catch (Exception $e) {
                echo '<p style="color: red; text-align: center;">Message could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</p>';
            }
        }

        header("Location: user_dashboard.php");
        exit;
    } else {
        $error_message = "Error reporting incident: " . mysqli_error($conn);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report an Incident</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <h3 class="text-center">Report an Incident</h3>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="report_type" class="form-label">Who are you reporting for?</label>
                    <select id="report_type" class="form-select" name="report_type" required>
                        <option value="self">Myself</option>
                        <option value="someone_else">Someone Else</option>
                    </select>
                </div>

                <div class="mb-3" id="user_dropdown" style="display: none;">
                    <label for="reported_for" class="form-label">Select a user from your department</label>
                    <select id="reported_for" class="form-select" name="reported_for">
                        <option value="">-- Select User --</option>
                        <?php
                        include "connection.php";
                       
                        $user_id = $_SESSION['user_id'];

                        // Get the current user's department ID
                        $dept_query = "SELECT department_id FROM users WHERE id = '$user_id'";
                        $dept_result = mysqli_query($conn, $dept_query);
                        $dept = mysqli_fetch_assoc($dept_result);
                        $department_id = $dept['department_id'];

                        // Fetch users from the same department
                        $users_query = "SELECT id, CONCAT(first_name, ' ', middle_name, ' ', last_name) AS full_name, email FROM users WHERE department_id = '$department_id' AND id != '$user_id'";
                        $users_result = mysqli_query($conn, $users_query);

                        while ($row = mysqli_fetch_assoc($users_result)) {
                            echo "<option value='{$row['email']}'>{$row['full_name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="category" class="form-label">Category</label>
                    <select id="category" class="form-select" name="category" required>
                    <option value=>...Select...</option>
                        <option value="Hardware">Hardware</option>
                        <option value="Software">Software</option>
                        <option value="Network">Network</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="priority" class="form-label">Priority</label>
                    <select id="priority" class="form-select" name="priority" required>
                    <option value=>...Select...</option>
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea id="description" class="form-control" name="description" rows="3" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="screenshot" class="form-label">Upload Screenshot (Optional)</label>
                    <input type="file" class="form-control" id="screenshot" name="screenshot">
                </div>

                <button type="submit" class="btn btn-primary w-100">Submit Report</button>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('#report_type').change(function () {
                if ($(this).val() === 'someone_else') {
                    $('#user_dropdown').slideDown();
                } else {
                    $('#user_dropdown').slideUp();
                }
            });
        });
    </script>
</body>
</html>
