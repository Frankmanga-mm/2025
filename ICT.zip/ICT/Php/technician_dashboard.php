<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/Exception.php';
include "connection.php";

// Ensure technician is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: login.php");
    exit;
}

$technician_id = $_SESSION['user_id'];

// Fetch incidents assigned to this technician
$incidents_query = "SELECT id, ticket_number, reported_by FROM incidents WHERE assigned_technician = '$technician_id' AND status = 'In Progress'";
$incidents_result = mysqli_query($conn, $incidents_query);

// Debugging: Check if the query ran successfully
if (!$incidents_result) {
    die("Error fetching incidents: " . mysqli_error($conn));  // Output any query error
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#ticket_number').on('keyup', function() {
                var query = $(this).val();
                $.ajax({
                    url: 'search_incidents.php',
                    method: 'POST',
                    data: { ticket_number: query },
                    success: function(data) {
                        $('#incidentTable tbody').html(data);
                    }
                });
            });

            // When a ticket number is clicked, fetch and display the incident details below the table
            $('.ticket-link').on('click', function(e) {
                e.preventDefault();
                var ticketId = $(this).data('ticket-id');

                $.ajax({
                    url: 'get_incident_details.php',
                    method: 'POST',
                    data: { ticket_id: ticketId },
                    success: function(response) {
                        $('#incidentDetails').html(response);
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <h3 class="text-center">Technician Dashboard</h3>
        <p class="text-center">Manage and resolve incidents assigned to you</p>

        <form class="mb-4">
            <input type="text" id="ticket_number" name="ticket_number" class="form-control" placeholder="Search by Ticket Number">
        </form>

        <table class="table table-bordered" id="incidentTable">
            <thead>
                <tr>
                    <th>SNo</th>
                    <th>Ticket #</th>
                    <th>Reported By</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $sno = 1; 
                    while ($row = mysqli_fetch_assoc($incidents_result)) { 
                ?>
                    <tr>
                        <td><?= $sno++ ?></td>
                        <td>
                            <a href="#" class="ticket-link" data-ticket-id="<?= $row['id'] ?>">
                                <?= $row['ticket_number'] ?>
                            </a>
                        </td>
                        <td><?= $row['reported_by'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Section to display incident details below the table -->
        <div id="incidentDetails" class="mt-4"></div>
    </div>
</body>
</html>
