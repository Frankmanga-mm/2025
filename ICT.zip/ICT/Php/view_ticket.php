<?php
session_start();

require_once 'connection.php'; // Include database connection
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';


if ($_SESSION['role'] !== 'user' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit;
}

// Check if ticket number is provided
if (!isset($_GET['ticket_number'])) {
    die("Invalid request.");
}

$ticket_number = $_GET['ticket_number'];

// Fetch full ticket details
$sql = "SELECT * FROM tickets WHERE ticket_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $ticket_number);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Ticket not found.");
}

$ticket = $result->fetch_assoc();

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $comment = mysqli_real_escape_string($conn, trim($_POST['comment']));
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

    // Insert comment into the database
    $comment_sql = "INSERT INTO comments (ticket_number, user_id, comment) VALUES (?, ?, ?)";
    $comment_stmt = $conn->prepare($comment_sql);
    $comment_stmt->bind_param("sis", $ticket_number, $user_id, $comment);

    if ($comment_stmt->execute()) {
        // Fetch the email of the user who reported the ticket
        $reported_by_email = $ticket['reported_by'];

        // Fetch admin emails
        $admin_sql = "SELECT email FROM users WHERE role = 'admin'";
        $admin_result = $conn->query($admin_sql);
        $admin_emails = [];
        while ($row = $admin_result->fetch_assoc()) {
            $admin_emails[] = $row['email'];
        }

        // Send email notifications
        $subject = "New Comment on Ticket: $ticket_number";
        $body = "A new comment has been added to a ticket (Ticket Number: $ticket_number).<br><br>
                 Comment: $comment<br><br>
                 Regards,<br>ICT-Incident-Reporting-System Team";

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mlelwaimma99@gmail.com';
            $mail->Password = 'haxu ddpx szus blnx';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Send to the user who reported the ticket
            $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($reported_by_email);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->send();

            // Send to all admins
            foreach ($admin_emails as $admin_email) {
                $mail->clearAddresses(); // Clear previous addresses
                $mail->addAddress($admin_email);
                $mail->send();
            }
        } catch (Exception $e) {
            // Handle email sending error
        }

        // Redirect to the same page to prevent form resubmission
        header("Location: view_ticket.php?ticket_number=" . urlencode($ticket_number));
        exit();
    }
}

// Fetch comments for the ticket
$comments_sql = "SELECT comments.comment, comments.created_at, users.first_name, comments.user_id FROM comments 
                 JOIN users ON comments.user_id = users.id 
                 WHERE ticket_number = ? ORDER BY created_at ASC";
$comments_stmt = $conn->prepare($comments_sql);
$comments_stmt->bind_param("s", $ticket_number);
$comments_stmt->execute();
$comments_result = $comments_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Ticket</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 6%;
            margin-left: 17%;
        }
        .card {
            padding: 20px;
            border-radius: 10px;
        }
        .back-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
        .comment-section {
            margin-top: 30px;
        }
        .comments-container {
            display: flex;
            flex-direction: column;
        }
        .comment {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            max-width: 70%; /* Limit the width of comments */
        }
        .admin-comment {
            background-color: #d1ecf1; /* Light blue for admin comments */
            align-self: flex-start; /* Align admin comments to the left */
        }
        .user-comment {
            background-color: #c3e6cb; /* Light green for user comments */
            align-self: flex-end; /* Align user comments to the right */
        }
    </style>
</head>
<body>

<?php include 'userheader.php'; ?>
<?php include 'usersidebar.php'; ?>
<div class="container">
    <h2 class="text-center mb-4">Ticket Details</h2>
    <div>
        <a href="my_tickets.php" class="back-btn" style="margin-bottom: 20px; display: inline-block;">Back to My Tickets</a>
    </div>
    <div class="card shadow">
        <p><strong>Ticket Number:</strong> <?= htmlspecialchars($ticket['ticket_number']) ?></p>
        <p><strong>Priority:</strong> <?= htmlspecialchars($ticket['priority']) ?></p>
        <p><strong>Category:</strong> <?= htmlspecialchars($ticket['category']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($ticket['description']) ?></p>

        <!-- Display Screenshot if Available -->
        <?php if (!empty($ticket['screenshot'])): 
            // Ensure the correct path format
            $imagePath = trim($ticket['screenshot']); 
        ?>
            <p><strong>Screenshot:</strong></p>
            <img src="<?= $imagePath ?>" width="400" alt="Ticket Screenshot " class="img-thumbnail">
        <?php else: ?>
            <p><em>No screenshot available.</em></p>
        <?php endif; ?>

        <p><strong>Reported By:</strong> <?= htmlspecialchars($ticket['reported_by']) ?></p>
        <p><strong>Reported To:</strong> <?= htmlspecialchars($ticket['reported_to']) ?></p>
        <p><strong>Created At:</strong> <?= date("d M Y H:i", strtotime($ticket['created_at'])) ?></p>

        <p><strong>Last Updated:</strong> 
            <?php 
                if (!empty($ticket['last_updated']) && $ticket['last_updated'] != $ticket['created_at']) {
                    echo date("d M Y H:i", strtotime($ticket['last_updated']));
                } else {
                    echo "No updates yet on the ticket";
                }
            ?>
        </p>

        <p><strong>Status:</strong>
            <span class="badge bg-<?php 
                echo ($ticket['status'] == 'Open') ? 'danger' :
                     (($ticket['status'] == 'In Progress') ? 'warning' :
                     (($ticket['status'] == 'Resolved') ? 'success' : 'secondary'));
            ?>">
                <?= htmlspecialchars($ticket['status']) ?>
            </span>
        </p>
    </div>

    <div class="comment-section">
        <h4 class="mt-4">Comments</h4>
        <div class="comments-container">
            <?php while ($comment = $comments_result->fetch_assoc()): ?>
                <div class="comment <?= ($comment['user_id'] == $_SESSION['user_id']) ? 'user-comment' : 'admin-comment' ?>">
                    <strong><?= htmlspecialchars($comment['first_name']) ?>:</strong>
                    <p><?= htmlspecialchars($comment['comment']) ?></p>
                    <small><?= date("d M Y H:i", strtotime($comment['created_at'])) ?></small>
                </div>
            <?php endwhile; ?>
        </div>

        <form method="POST" class="mt-3">
            <div class="form-group">
                <label for="comment">Add a Comment:</label>
                <textarea id="comment" name="comment" class="form-control" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary mt-2">Submit Comment</button>
        </form>
    </div>
</div>

</body>
</html>

<?php
$stmt->close();
$comments_stmt->close();
$conn->close();
?>