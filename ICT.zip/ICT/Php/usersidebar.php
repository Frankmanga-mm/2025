<nav class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link " href="raise_ticket.php">Raise Ticket</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="my_tickets.php">My Tickets</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="changepassword.php">Profile settings</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-danger" href="logout.php">Logout</a>
        </li>
    </ul>
</nav>