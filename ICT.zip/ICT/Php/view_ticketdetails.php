<?php
session_start();
require_once 'connection.php'; // Include database connection
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';



// Check if ticket number is provided
if (!isset($_GET['ticket_number'])) {
    die("Invalid request.");
}

$ticket_number = $_GET['ticket_number'];

// Fetch full ticket details
$sql = "SELECT * FROM tickets WHERE ticket_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $ticket_number);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Ticket not found.");
}

$ticket = $result->fetch_assoc();

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $comment = mysqli_real_escape_string($conn, trim($_POST['comment']));
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

    // Insert comment into the database
    $comment_sql = "INSERT INTO comments (ticket_number, user_id, comment) VALUES (?, ?, ?)";
    $comment_stmt = $conn->prepare($comment_sql);
    $comment_stmt->bind_param("sis", $ticket_number, $user_id, $comment);

    if ($comment_stmt->execute()) {
        // Send email notification
        $subject = "New Comment on Ticket: $ticket_number";
        $body = "A new comment has been added to your ticket (Ticket Number: $ticket_number).<br><br>
                 Comment: $comment<br><br>
                 Regards,<br>ICT-Incident-Reporting-System Team";

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mlelwaimma99@gmail.com';
            $mail->Password = 'haxu ddpx szus blnx';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($ticket['reported_by']); // Assuming reported_by is the user's email

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;

            $mail->send();
        } catch (Exception $e) {
            // Handle email sending error
        }

        // Redirect to the same page to prevent form resubmission
        header("Location: view_ticketdetails.php?ticket_number=" . urlencode($ticket_number));
        exit();
    }
}

// Fetch comments for the ticket
$comments_sql = "SELECT comments.comment, comments.created_at, comments.user_id, users.first_name FROM comments 
JOIN users ON comments.user_id = users.id 
WHERE ticket_number = ? ORDER BY created_at ASC";
$comments_stmt = $conn->prepare($comments_sql);
$comments_stmt->bind_param("s", $ticket_number);
$comments_stmt->execute();
$comments_result = $comments_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Ticket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .back-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
        .comment-section {
            margin-top: 30px;
        }
        .comments-container {
            display: flex;
            flex-direction: column;
        }
        .comment {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            max-width: fit-content; /* Limit the width of comments to fit the content */
        }
        .admin-comment {
    background-color: #d1ecf1; /* Light blue for admin comments */
    align-self: flex-start; /* Align admin comments to the left */
}

.user-comment {
    background-color: #c3e6cb; /* Light green for user comments */
    align-self: flex-end; /* Align user comments to the right */
}
    </style>
</head>
<body>


<?php include 'adminheader.php'; ?>
    <?php include 'adminsidebar.php'; ?>


<div class="container">
    <h2 class="text-center mb-4">Ticket Details</h2>
    <div>
        <a href="Raised_tickets.php" class="back-btn" style="margin-bottom: 20px; display: inline-block;">Back to Tickets</a>
    </div>
    <div class="card shadow">
        <p><strong>Ticket Number:</strong> <?= htmlspecialchars($ticket['ticket_number']) ?></p>
        <p><strong>Priority:</strong> <?= htmlspecialchars($ticket['priority']) ?></p>
        <p><strong>Category:</strong> <?= htmlspecialchars($ticket['category']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($ticket['description']) ?></p>

        <?php if (!empty($ticket['screenshot'])): ?>
            <p><strong>Screenshot:</strong></p>
            <img src="<?= htmlspecialchars($ticket['screenshot']) ?>" width="400" alt="Ticket Screenshot" class="img-thumbnail">
        <?php else: ?>
            <p><em>No screenshot available.</em></p>
        <?php endif; ?>

        <p><strong>Reported By:</strong> <?= htmlspecialchars($ticket['reported_by']) ?></p>
        <p><strong>Reported To:</strong> <?= htmlspecialchars($ticket['reported_to']) ?></p>
        <p><strong>Created At:</strong> <?= date("d M Y H:i", strtotime($ticket['created_at'])) ?></p>

        <p><strong>Last Updated:</strong> 
            <?= (!empty($ticket['last_updated']) && $ticket['last_updated'] != $ticket['created_at']) ? date("d M Y H:i", strtotime($ticket['last_updated'])) : "No updates yet on the ticket"; ?>
        </p>

        <p><strong>Status:</strong>
            <span class="badge bg-<?php 
                echo ($ticket['status'] == 'Open') ? 'danger' :
                     (($ticket['status'] == 'In Progress') ? 'warning' :
                     (($ticket['status'] == 'Resolved') ? 'success' : 'secondary'));
            ?>">
                <?= htmlspecialchars($ticket['status']) ?>
            </span>
        </p>
    </div>

    <div class="comment-section">
    <h4>Comments</h4>
    <div class="comments-container">
        <?php while ($comment = $comments_result->fetch_assoc()): ?>
            <div class="comment <?= ($comment['user_id'] == $_SESSION['user_id']) ? 'admin-comment' : 'user-comment' ?>">
                <p><strong><?= htmlspecialchars($comment['first_name']) ?> commented on <?= date("d M Y H:i", strtotime($comment['created_at'])) ?>:</strong></p>
                <p><?= htmlspecialchars($comment['comment']) ?></p>
            </div>
        <?php endwhile; ?>
    </div>
</div>

    <div class="comment-form">
        <form method="POST">
            <div class="mb-3">
                <label for="comment" class="form-label">Add a Comment</label>
                <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Post Comment</button>
        </form>
    </div>
</div>

</body>
</html>


<script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        function toggleDropdown(event, id) {
            event.preventDefault();
            var dropdown = document.getElementById(id);
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
<?php
$stmt->close();
$comments_stmt->close();
$conn->close();
?>