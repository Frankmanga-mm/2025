<?php
session_start();
require_once 'connection.php'; // Include database connection

// Check if admin is logged in
if (!isset($_SESSION['user_email'])) {
    header("Location: ../index.php");
    exit();
}

$reportType = isset($_POST['report_type']) ? $_POST['report_type'] : 'daily'; // Default to daily
$statusFilter = isset($_POST['status_filter']) ? $_POST['status_filter'] : 'all'; // Default to all statuses

// Define SQL query based on selected report type
switch ($reportType) {
    case 'weekly':
        $date_condition = "AND created_at >= CURDATE() - INTERVAL 1 WEEK";
        break;
    case 'monthly':
        $date_condition = "AND created_at >= CURDATE() - INTERVAL 1 MONTH";
        break;
    case 'annually':
        $date_condition = "AND created_at >= CURDATE() - INTERVAL 1 YEAR";
        break;
    case 'daily':
    default:
        $date_condition = "AND created_at >= CURDATE()";
        break;
}

// SQL query to fetch ticket statistics based on status
$status_condition = ($statusFilter !== 'all') ? "AND status = '$statusFilter'" : '';

// SQL query for counting tickets with different statuses (Open, In Progress, Closed)
$sql = "SELECT 
            COUNT(*) AS total_tickets,
            SUM(CASE WHEN status = 'Open' THEN 1 ELSE 0 END) AS open_tickets,
            SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) AS in_progress_tickets,
            SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END) AS closed_tickets
        FROM tickets
        WHERE 1 $date_condition $status_condition";

$result = $conn->query($sql);
$reportData = $result->fetch_assoc();

$totalTickets = $reportData['total_tickets'];
$openTickets = $reportData['open_tickets'];
$inProgressTickets = $reportData['in_progress_tickets'];
$closedTickets = $reportData['closed_tickets'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Report Dashboard</title>
    <!-- Bootstrap CSS -->
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 0;
        }

       

        header h2 {
            margin: 0;
        }

       

        .content-area {
            margin-left: 250px;
            padding: 80px 20px 20px;
            width: calc(100% - 250px);
            min-height: calc(100vh - 60px);
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

    


        .report-card {
            border-radius: 15px;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .select-container {
            margin-bottom: 30px;
        }

        .form-select {
            width: auto;
            margin: 0 15px;
        }

        .btn-primary, .btn-secondary {
            border-radius: 25px;
        }

        .btn-primary {
            background-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php include 'adminheader.php'; ?>
<?php include 'adminsidebar.php'; ?>



<main class="content-area">
    <div class="container">
    <h2 class="text-center mb-4">Reports are managed here </h2>

        <h2 class="mb-4">Ticket Report Dashboard</h2>

        <div class="select-container">
            <form method="POST" class="text-center">
                <label for="report_type" class="form-label">Select Report Type:</label>
                <select name="report_type" id="report_type" class="form-select d-inline" onchange="this.form.submit()">
                    <option value="daily" <?= ($reportType == 'daily') ? 'selected' : ''; ?>>Daily</option>
                    <option value="weekly" <?= ($reportType == 'weekly') ? 'selected' : ''; ?>>Weekly</option>
                    <option value="monthly" <?= ($reportType == 'monthly') ? 'selected' : ''; ?>>Monthly</option>
                    <option value="annually" <?= ($reportType == 'annually') ? 'selected' : ''; ?>>Annually</option>
                </select>
                
                <label for="status_filter" class="form-label ms-3">Select Ticket Status:</label>
                <select name="status_filter" id="status_filter" class="form-select d-inline" onchange="this.form.submit()">
                    <option value="all" <?= ($statusFilter == 'all') ? 'selected' : ''; ?>>All</option>
                    <option value="Open" <?= ($statusFilter == 'Open') ? 'selected' : ''; ?>>Open</option>
                    <option value="In Progress" <?= ($statusFilter == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                    <option value="Closed" <?= ($statusFilter == 'Closed') ? 'selected' : ''; ?>>Closed</option>
                </select>
            </form>
        </div>

        <div class="card report-card shadow p-4">
            <h4 class="text-center">Report for: <?= ucfirst($reportType) ?> - Status: <?= ucfirst($statusFilter) ?></h4>

            <?php if ($totalTickets > 0): ?>
                <p><strong>Total Tickets: </strong><?= $totalTickets ?></p>
                <p><strong>Open Tickets: </strong><?= $openTickets ?></p>
                <p><strong>In Progress Tickets: </strong><?= $inProgressTickets ?></p>
                <p><strong>Closed Tickets: </strong><?= $closedTickets ?></p>
            <?php else: ?>
                <p>No tickets available for this period and status.</p>
            <?php endif; ?>
        </div>

        <!-- Print Report Link -->
        <a href="Grenerate_report.php?report_type=<?= $reportType ?>&status_filter=<?= $statusFilter ?>" class="btn btn-primary mb-3">Print Report</a>
    </div>
</main>





<script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        function toggleDropdown(event, id) {
            event.preventDefault();
            var dropdown = document.getElementById(id);
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
