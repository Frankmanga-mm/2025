<?php
require_once('tcpdf/tcpdf.php');
require_once 'connection.php';

// Get the selected report type and status filter from the URL
$reportType = isset($_GET['report_type']) ? $_GET['report_type'] : 'daily'; // Default to daily
$statusFilter = isset($_GET['status_filter']) ? $_GET['status_filter'] : 'all'; // Default to all statuses

// Define SQL query based on selected report type
switch ($reportType) {
    case 'weekly':
        $date_condition = "AND created_at >= CURDATE() - INTERVAL 1 WEEK";
        break;
    case 'monthly':
        $date_condition = "AND created_at >= CURDATE() - INTERVAL 1 MONTH";
        break;
    case 'annually':
        $date_condition = "AND created_at >= CURDATE() - INTERVAL 1 YEAR";
        break;
    case 'daily':
    default:
        $date_condition = "AND created_at >= CURDATE()";
        break;
}

// SQL query to fetch tickets based on the status and report type
$status_condition = ($statusFilter !== 'all') ? "AND status = '$statusFilter'" : '';
$sql = "SELECT ticket_number, description, status, priority, created_at, reported_by FROM tickets WHERE 1 $date_condition $status_condition ORDER BY created_at DESC";
$result = $conn->query($sql);

// Create new PDF document
$pdf = new TCPDF('L', PDF_UNIT, 'A4', true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetTitle('ICT Incident Report');

// Set margins
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(TRUE, 10);
$pdf->AddPage();

// Title & Timestamp
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, 'ICT Incident Report', 0, 1, 'C');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 10, 'Generated on: ' . date('d M Y H:i:s'), 0, 1, 'C');

// Display report type and status
$pdf->SetFont('helvetica', 'I', 12);
$pdf->Cell(0, 10, 'Report Type: ' . ucfirst($reportType) . ' - Status: ' . ucfirst($statusFilter), 0, 1, 'C');

// Table Headers with visible borders
$html = '<style>
th { background-color: #007bff; color: white; padding: 5px; text-align: center; }
td { padding: 5px; border: 1px solid #ddd; text-align: center; }
.status-Open { color: red; font-weight: bold; }
.status-InProgress { color: orange; font-weight: bold; }
.status-Resolved { color: green; font-weight: bold; }
</style>';

$html .= '<table border="1" cellspacing="0" cellpadding="4">';
$html .= '<tr style="background-color:#007bff; color:#fff;">
            <th>#</th>
            <th>Ticket Number</th>
            <th>Description</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Reported By</th>
            <th>Reported Time</th>
        </tr>';

$counter = 1;
$totalTickets = 0; // Count the total number of tickets
while ($row = $result->fetch_assoc()) {
    $statusClass = 'status-' . str_replace(' ', '', $row['status']);
    $html .= '<tr>
                <td>' . $counter++ . '</td>
                <td>' . htmlspecialchars($row['ticket_number']) . '</td>
                <td>' . htmlspecialchars($row['description']) . '</td>
                <td class="' . $statusClass . '">' . htmlspecialchars($row['status']) . '</td>
                <td>' . htmlspecialchars($row['priority']) . '</td>
                <td>' . htmlspecialchars($row['reported_by']) . '</td>
                <td>' . date('d M Y H:i', strtotime($row['created_at'])) . '</td>
             </tr>';
    $totalTickets++;
}
$html .= '</table>';

// Print Table
$pdf->writeHTML($html, true, false, true, false, '');

// Display total number of tickets
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Ln(10); // Add line break
$pdf->Cell(0, 10, 'Total Tickets: ' . $totalTickets, 0, 1, 'C');

// Output PDF
$pdf->Output('ICT_Incident_Report.pdf', 'D');
?>
