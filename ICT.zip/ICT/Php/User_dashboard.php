<?php

session_start();
if ($_SESSION['role'] !== 'user' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit;
}
require_once 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'userheader.php'; ?>
<?php include 'usersidebar.php'; ?>

<main class="content-area">
    <div class="container">
        <h3>Welcome, User</h3>
        <p>Manage your tickets and account settings from the sidebar menu.</p>
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Dashboard Overview</h4>
                <p>Use this dashboard to raise incidents and track their status.</p>
                <a href="raise_ticket.php" class="btn btn-primary">Raise a New Ticket</a>
            </div>
        </div>
    </div>
</main>

<?php include 'userfooter.php'; ?>

<script>
    function toggleSidebar() {
        document.querySelector('.sidebar'). classList.toggle('active');
    }
</script>

</body>
</html>