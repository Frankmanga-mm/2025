<?php
// Database configuration
$host = "localhost"; // Change if using a remote database
$dbname = "ict_incident_reporting"; 
$username = "root"; // Change if using a different user
$password = ""; // Change if a password is set

// Create a connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8 (optional but recommended)
$conn->set_charset("utf8");

// Uncomment for debugging
// echo "Database connected successfully";

?>
