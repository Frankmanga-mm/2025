<?php
session_start();
require_once 'connection.php';// Include database connection

// Check if user is logged in
if (!isset($_SESSION['user_email'])) {
    header("Location: ../index.php");
    exit();
}

$user_email = $_SESSION['user_email'];

// Fetch tickets for the logged-in user
$sql = "SELECT ticket_number, description, created_at, status FROM tickets WHERE reported_by = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tickets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 6%;
            margin-left: 17%;
        }
        .card {
            border-radius: 10px;
        }
        .table {
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }
        th {
            background: #007bff;
            color: white;
            text-align: center;
        }
        .view-btn {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .view-btn:hover {
            background-color: #218838;
        }

       
    </style>
</head>
<body>
<?php include 'userheader.php'; ?>
<?php include 'usersidebar.php'; ?>


<div class="container">
    <h2 class="text-center mb-4">My Tickets</h2>
    <div class="card shadow p-4">
    <table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>#</th> <!-- Added numbering column -->
            <th>Ticket Number</th>
            <th>Description</th>
            <th>Raised On </th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $counter = 1; // Initialize counter
        while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td class="text-center"><?= $counter++ ?></td> <!-- Display counter and increment it -->
            <td class="text-center"><?= htmlspecialchars($row['ticket_number']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td class="text-center"><?= date("d M Y H:i", strtotime($row['created_at'])) ?></td>
            <td class="text-center">
                <span class="badge bg-<?php 
                    echo ($row['status'] == 'Open') ? 'danger' :
                         (($row['status'] == 'In Progress') ? 'warning' :
                         (($row['status'] == 'Resolved') ? 'success' : 'secondary'));
                ?>">
                    <?= htmlspecialchars($row['status']) ?>
                </span>
            </td>
            <td class="text-center">
                <a href="view_ticket.php?ticket_number=<?= urlencode($row['ticket_number']) ?>" class="view-btn">View Ticket</a>
            </td>
        </tr>
        <?php } ?>
        <?php if ($result->num_rows === 0) { ?>
            <tr>
                <td colspan="6" class="text-center text-muted">No tickets found.</td> <!-- Adjusted colspan to 6 -->
            </tr>
        <?php } ?>
    </tbody>
</table>

    </div>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
