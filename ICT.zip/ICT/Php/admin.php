<?php
session_start();
if ($_SESSION['role'] !== 'admin' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit;
}
require_once 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
</head>
<body>

    <?php include 'adminheader.php'; ?>
    <?php include 'adminsidebar.php'; ?>

    <!-- Main Content -->
    <main class="content-area">
        <div class="container">
            <h3 class="mt-3">Welcome, Admin</h3>
            <div class="card mt-4">
                <div class="card-body">
                    <h4 class="card-title">Dashboard Overview</h4>
                    <p>Manage incidents, users, and system settings from the navigation menu.</p>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#addDepartmentModal">Add Department</button>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal -->
    <div class="modal fade" id="addDepartmentModal" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <form action="add_department.php" method="POST" class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Department</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Department Name</label>
                        <input type="text" class="form-control" name="department_name" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Add Department</button>
                </div>
            </form>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    
</body>
</html>
