<footer>
    <p>Incident Reporting System @2025</p>
</footer>