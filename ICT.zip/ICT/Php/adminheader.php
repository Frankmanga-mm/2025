<!-- header to be used in admin pages -->
<header>
    <h2>Admin Dashboard</h2>
    <button class="navbar-toggler" type="button" onclick="toggleSidebar()">
        <span class="navbar-toggler-icon"></span>
    </button>
</header>
