<?php
session_start();
require_once 'connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';
// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

$user_id = $_SESSION['user_id'];
$user_email = $_SESSION['user_email'];
$user_name = $_SESSION['user_name'];
$department_id = isset($_SESSION['department_id']) ? $_SESSION['department_id'] : null;

// Fetch admin email dynamically
$admin_query = "SELECT email FROM users WHERE role = 'admin' LIMIT 1";
$admin_result = $conn->query($admin_query);
$admin_email = ($admin_result->num_rows > 0) ? $admin_result->fetch_assoc()['email'] : "admin@example.com";

// Generate a unique ticket number
$ticket_number = "TKT-" . strtoupper(uniqid());

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category = $_POST['category'];
    $priority = $_POST['priority'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Handle file upload
    $screenshot = "";
    if (!empty($_FILES['screenshot']['name'])) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $max_size = 5 * 1024 * 1024; // 5MB

        if (in_array($_FILES['screenshot']['type'], $allowed_types) && $_FILES['screenshot']['size'] <= $max_size) {
            $screenshot = "../assets/ticketuploads/" . time() . "_" . basename($_FILES['screenshot']['name']);
            move_uploaded_file($_FILES['screenshot']['tmp_name'], $screenshot);
        } else {
            echo "<script>alert('Invalid file type or size exceeded.');</script>";
        }
    }

    // Prepare statement
    $stmt = $conn->prepare("INSERT INTO tickets 
    (user_id, priority, ticket_number, description, category, status, created_at, screenshot, reported_by, reported_to) 
    VALUES (?, ?, ?, ?, ?, 'Open', NOW(), ?, ?, ?)");
    
    if (!$stmt) {
        die("SQL Error: " . $conn->error); // Debug SQL error
    }
    
    // Bind parameters correctly
    $stmt->bind_param("isssssss", $user_id, $priority, $ticket_number, $description, $category, $screenshot, $user_email, $admin_email);
    
    if ($stmt->execute()) {
        // Send Email to User
        sendEmail($user_email, "Dear $user_name,<br>Your request ($ticket_number) has been submitted to the ICT department.<br>Thank you for using the ICT Incident Reporting System.");

        // Send Email to Admin
        sendEmail($admin_email, "Greetings Admin,</br>New Ticket ($ticket_number) raised by $user_name ($user_email).");

        echo "<div class='alert alert-success'>Ticket submitted successfully!</div>";
    echo "<script>setTimeout(function(){ window.location.href = 'raise_ticket.php'; }, 2000);</script>"; // Redirect after 2 seconds
    } else {
        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();
    $conn->close();
}

// Function to Send Email
function sendEmail($to, $message) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mlelwaimma99@gmail.com'; // Replace with your email
        $mail->Password = 'haxu ddpx szus blnx'; // Use an App Password, not your real password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = 'Ticket Notification';
        $mail->Body = $message;
        $mail->send();
    } catch (Exception $e) {
        error_log("Email failed: " . $mail->ErrorInfo);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <link rel="stylesheet" href="styles.css">



    <style>
      .container {
            margin-top: 6%;
            margin-left: 17%;
        }
    </style>
</head>
<body>

<?php include 'userheader.php'; ?>
<?php include 'usersidebar.php'; ?>

    <div class="container">
        <div class="card">
        <div class="card-header" style="background-color: #1e1e2d; color: white; text-align: center;">
                <h4>Raise a Ticket</h4>
            </div>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <!-- Category Dropdown -->
                    <div class="form-group">
                        <label>Category:</label>
                        <select class="form-control" name="category" required>
                            <option value="">Select category</option>
                            <?php
                            $categories = $conn->query("SELECT name FROM categories");
                            while ($cat = $categories->fetch_assoc()) {
                                echo "<option value='{$cat['name']}'>{$cat['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Priority Dropdown -->
                    <div class="form-group">
                        <label>Priority:</label>
                        <select class="form-control" name="priority" required>
                            <option value="">Select Priority</option>
                            <?php
                            $priorities = $conn->query("SELECT name FROM priorities");
                            while ($prio = $priorities->fetch_assoc()) {
                                echo "<option value='{$prio['name']}'>{$prio['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Description -->
                    <div class="form-group">
                        <label>Description:</label>
                        <textarea class="form-control" name="description" rows="4" required></textarea>
                    </div>

                    <!-- Upload Screenshot (Optional) -->
                    <div class="form-group">
                        <label>Upload Screenshot (Optional - JPG, JPEG, PNG, Max 5MB):</label>
                        <input type="file" class="form-control" name="screenshot">
                    </div>
                    <button type="submit" class="btn btn-success btn-block" style="background-color: #1e1e2d; border: none;">Submit Ticket</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
