<?php
session_start();

// Redirect if the role is not 'admin' or the username is empty
if ($_SESSION['role'] !== 'admin' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit; // Ensure script stops execution after redirection
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

require_once 'connection.php';

// Handle messages (success/error)
$message = "";
if (isset($_GET['msg'])) {
    $message = htmlspecialchars($_GET['msg']);
}

// Pagination variables
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 5; // Default limit set to 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Default page
$offset = ($page - 1) * $limit;

// Fetch users with department names
$query = "SELECT users.id, users.first_name, users.middle_name, users.last_name, users.email, users.phone, departments.name AS department 
          FROM users 
          LEFT JOIN departments ON users.department_id = departments.id 
          LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);

// Fetch total number of users for pagination
$total_query = "SELECT COUNT(*) as total FROM users";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_users = $total_row['total'];
$total_pages = ceil($total_users / $limit);


//Fetch departments and store options 
$dept_options = ""; 
$dept_query = "SELECT * FROM departments"; 

 $dept_result = mysqli_query($conn, $dept_query); 
 while ($dept = mysqli_fetch_assoc($dept_result))
  { $dept_options .= "<option value='{$dept['id']}'>" . htmlspecialchars(string: $dept['name']) . "</option>"; } 
  // Fetch departments for dropdown
   $dept_query = "SELECT id, name FROM departments"; 
   $dept_result = mysqli_query($conn, $dept_query); 
   // Error handling for department fetch 
   
   if (!$dept_result) { die("Error fetching departments: " . mysqli_error($conn)); }

// Handle Delete Request
if (isset($_POST['delete_user'])) {
    $id = $_POST['user_id'];
    $delete_query = "DELETE FROM users WHERE id = '$id'";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: manage_users.php?msg=User  deleted successfully!");
        exit();
    } else {
        header("Location: manage_users.php?msg=Error deleting user.");
        exit();
    }
}

// Handle Edit Request
if (isset($_POST['edit_user'])) {
    $id = $_POST['user_id'];
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $middle_name = mysqli_real_escape_string($conn, $_POST['middle_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $department_id = mysqli_real_escape_string($conn, $_POST['department_id']);


    $update_query = "UPDATE users SET 
                     first_name='$first_name', 
                     middle_name='$middle_name', 
                     last_name='$last_name', 
                     email='$email', 
                     phone='$phone', 
                     department_id='$department_id' 
                     WHERE id='$id'";

    if (mysqli_query($conn, $update_query)) {
        header("Location: manage_users.php?msg=User  updated successfully!");
        exit();
    } else {
        die("Error updating user: " . mysqli_error($conn)); // Debugging error
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form data
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $middle_name = mysqli_real_escape_string($conn, $_POST['middle_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $department_id = mysqli_real_escape_string($conn, $_POST['department_id']);

    // Prepare and execute the SQL query to insert the new user into the database
    $query = "INSERT INTO users (first_name, middle_name, last_name, email, phone, department_id) 
              VALUES ('$first_name', '$middle_name', '$last_name', '$email', '$phone', '$department_id')";

    if (mysqli_query($conn, $query)) {
        // Send the email with a password creation link after inserting into the database
        $mail = new PHPMailer(true); // Set true for exceptions

        try {
            // Server settings for Gmail SMTP
            $mail->SMTPDebug = SMTP::DEBUG_SERVER; // For debugging, check SMTP logs
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // SMTP server
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'mlelwaimma99@gmail.com'; // SMTP username (use your Gmail username)
            $mail->Password = 'haxu ddpx szus blnx'; // SMTP password (use your App Password here)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port = 587; // TCP port to connect to

            // Recipients
            $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($email); // Add recipient email

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'Create Your Password';
            $mail->Body = "Hello $first_name,<br><br>Thank you for registering. To set your password, please click the link below:<br><br>
               <a href='http://localhost/ICT/Php/create_password.php?email=" . urlencode($email) . "'>Click here</a><br><br>
               Regards,<br>ICT Incident Reporting System";

            // Send email
            $mail->send();
            echo '<p style="color: green; text-align: center;">A password creation link has been sent to the email address provided.</p>';
        } catch (Exception $e) {
            echo '<p style="color: red; text-align: center;">Message could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</p>';
        }

        // PHP Redirection to manage users page
        header("Location: manage_users.php");
        exit; // Always call exit after a header redirection to stop further code execution
    } else {
        // If insertion fails, display an error message
        echo '<p style="color: red;">Error: ' . mysqli_error($conn) . '</p>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 6%;
            margin-left: 17%;
        }
        .table-responsive {
            max-height: 400px;
            overflow-y: auto;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .alert-message {
            display: none;
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 999;
        }
    </style>
</head>
<body>

<?php include 'adminheader.php'; ?>
<?php include 'adminsidebar.php'; ?>

<!-- Success or Error Message -->
<?php if (!empty($message)) : ?>
    <div class="alert alert-success alert-message"><?= $message ?></div>
    <script>
        setTimeout(() => {
            document.querySelector('.alert-message').style.display = 'none';
            window.location.href = "manage_users.php";
        }, 2000);
    </script>
<?php endif; ?>

<div class="container">
<h2 class="text-center mb-4">Manage Users</h2>

    <!-- Add User Button -->
    <button type="button" class="btn btn-success mb-3" data-toggle="modal" data-target="#addUserModal">Add User</button> <!-- Fixed ID -->

    <!-- Results per page selection -->
    <label for="limit">Results per page:</label>
    <select id="limit" class="form-control mb-3" onchange="changeLimit(this.value)">
        <option value="1" <?= $limit == 1 ? 'selected' : '' ?>>1</option>
        <option value="5" <?= $limit == 5 ? 'selected' : '' ?>>5</option>
        <option value="10" <?= $limit == 10 ? 'selected' : '' ?>>10</option>
        <option value="15" <?= $limit == 15 ? 'selected' : '' ?>>15</option>
    </select>

    <!-- Search Bar -->
    <input type="text" id="search" class="form-control mb-3" placeholder="Search by name, email, or department...">

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="userTable">
                <?php while ($user = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?= htmlspecialchars($user['first_name']) ?></td>
                        <td><?= htmlspecialchars($user['middle_name']) ?></td>
                        <td><?= htmlspecialchars($user['last_name']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['phone']) ?></td>
                        <td><?= $user['department'] ? htmlspecialchars($user['department']) : 'No Department' ?></td>
                        <td>
                            <!-- Edit Button -->
                            <button type="button" class="btn btn-warning btn-sm" 
                                onclick="openEditModal('<?= $user['id'] ?>', '<?= htmlspecialchars($user['first_name']) ?>', '<?= htmlspecialchars($user['middle_name']) ?>', '<?= htmlspecialchars($user['last_name']) ?>', '<?= htmlspecialchars($user['email']) ?>', '<?= htmlspecialchars($user['phone']) ?>')">
                                Edit
                            </button>

                            <!-- Delete Button -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                <button type="submit" name="delete_user" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete user ?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Controls -->
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                <a class="page-link" href="?page=<?= $page - 1 ?>&limit=<?= $limit ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>&limit=<?= $limit ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                <a class="page-link" href="?page=<?= $page + 1 ?>&limit=<?= $limit ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>

    <script>
        $(document).ready(function () {
            $("#search").on("keyup", function () {
                var value = $(this).val().toLowerCase();
                $("#userTable tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });
        });

        function changeLimit(limit) {
            window.location.href = "?limit=" + limit + "&page=1"; // Reset to first page
        }
    </script>
</div>

<!-- Add User Modal -->
<div id="addUserModal" class="modal fade"> <!-- Fixed ID -->
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h4 class="modal-title">Add User</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <label>First Name</label>
                    <input type="text" class="form-control mb-2" name="first_name" required>

                    <label>Middle Name</label>
                    <input type="text" class="form-control mb-2" name="middle_name">

                    <label>Last Name</label>
                    <input type="text" class="form-control mb-2" name="last_name" required>

                    <label>Email</label>
                    <input type="email" class="form-control mb-2" name="email" required>

                    <label>Phone</label>
                    <input type="text" class="form-control mb-2" name="phone" required>

                    <label>Department</label>
<select class="form-control mb-2" name="department_id" required>
    <?php while ($dept = mysqli_fetch_assoc($dept_result)) : ?>
        <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['name']) ?></option>
    <?php endwhile; ?>
</select>


                </div>
                <div class="modal-footer">
                    <button type="submit" name="add_user" class="btn btn-success">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>
 <!-- Edit Modal --> 
  <div id="editUserModal" class="modal fade">
     <div class="modal-dialog"> 
        <div class="modal-content"> 
            <form method="POST"> 
                <div class="modal-header"> 
                    <h4 class="modal-title">Edit User</h4> 
                    <button type="button" class="close" data-dismiss="modal">&times;</button> </div> <div class="modal-body"> <input type="hidden" name="user_id" id="edit_user_id">
            <label>First Name</label>
            <input type="text" class="form-control mb-2" name="first_name" id="edit_first_name" required>
            
            <label>Middle Name</label>
            <input type="text" class="form-control mb-2" name="middle_name" id="edit_middle_name">
            
            <label>Last Name</label>
            <input type="text" class="form-control mb-2" name="last_name" id="edit_last_name" required>
            
            <label>Email</label>
            <input type="email" class="form-control mb-2" name="email" id="edit_email" required>
            
            <label>Phone</label>
            <input type="text" class="form-control mb-2" name="phone" id="edit_phone" required>
            
            <label>Department</label>
            <select class="form-control mb-2" name="department_id" id="edit_department" required>
                <?= $dept_options ?> <!-- Insert department options -->
            </select>
        </div>
        <div class="modal-footer">
            <button type="submit" name="edit_user" class="btn btn-success">Save</button>
        </div>
    </form>
</div>
</div>
 </div> 
 <script> function openEditModal(id, firstName, middleName, lastName, email, phone, departmentId) 
 { $('#edit_user_id').val(id); 
    $('#edit_first_name').val(firstName);
     $('#edit_middle_name').val(middleName);
      $('#edit_last_name').val(lastName);
       $('#edit_email').val(email);
        $('#edit_phone').val(phone); 
        // Set selected department dynamically
         $('#edit_department').val(departmentId).change(); $('#editUserModal').modal('show'); }
</script>


<!-- Scripts -->
<script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        function toggleDropdown(event, id) {
            event.preventDefault();
            var dropdown = document.getElementById(id);
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>