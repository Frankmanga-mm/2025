<?php

session_start();

// Redirect if the role is not 'admin' or the username is empty
if ($_SESSION['role'] !== 'admin' || empty($_SESSION['user_name'])) {
    header("Location: ../index.php");
    exit; // Ensure script stops execution after redirection
}

require_once 'connection.php';

// Handle Adding Department
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_department'])) {
    $department_name = mysqli_real_escape_string($conn, trim($_POST['department_name']));
    if (!empty($department_name)) {
        $query = "INSERT INTO departments (name) VALUES ('$department_name')";
        if (mysqli_query($conn, $query)) {
            echo json_encode(["status" => "success", "message" => "Department added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to add department"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Department name cannot be empty"]);
    }
    exit();
}

// Handle Editing Department
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_department'])) {
    $id = intval($_POST['department_id']); // Ensure the ID is an integer
    $department_name = trim($_POST['department_name']); // No need to escape here

    if (!empty($department_name)) {
        $query = "UPDATE departments SET name = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "si", $department_name, $id);

        if (mysqli_stmt_execute($stmt)) {
            echo json_encode(["status" => "success", "message" => "Department updated successfully"]);
        } else {
            // Get the error message
            echo json_encode(["status" => "error", "message" => "Failed to update department: " . mysqli_error($conn)]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Department name cannot be empty"]);
    }
    exit();
}

// Handle Deleting Department
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM departments WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(["status" => "success", "message" => "Department deleted successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to delete department"]);
    }
    exit();
}

// Handle Live Search
if (isset($_GET['search'])) {
    $searchText = trim($_GET['search']);
    $query = "SELECT * FROM departments WHERE name LIKE ?";
    $stmt = mysqli_prepare($conn, $query);
    $param = "%{$searchText}%";
    mysqli_stmt_bind_param($stmt, "s", $param);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $departments = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $departments[] = ["id" => $row['id'], "name" => $row['name']];
    }
    echo json_encode($departments);
    exit();
}

// Pagination variables
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 5; // Default limit set to 5
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Default page
$offset = ($page - 1) * $limit;

// Fetch all departments for pagination
$query = "SELECT * FROM departments ORDER BY id ASC LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);

// Fetch total number of departments for pagination
$total_query = "SELECT COUNT(*) as total FROM departments";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_departments = $total_row['total'];
$total_pages = ceil($total_departments / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Departments</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body { background-color: #f4f4f4; }
        .container { margin-top: 90px; }
        .card { border-radius: 10px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); }
        .btn-custom { background-color: #007bff; color: white; border-radius: 5px; }
        .btn-custom:hover { background-color: #0056b3; }
        .table thead { background-color: #007bff; color: white; }
        
        header h2 {
            margin: 0;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>

<!-- Header -->
<?php include 'adminheader.php'; ?>
<?php include 'adminsidebar.php'; ?>

<div class="container">
    <h2 class="text-center mb-4">Manage Departments</h2>
    <div id="message" class="alert d-none"></div>

    <!-- Results per page selection -->
    <label for="limit">Results per page:</label>
    <select id="limit" class="form-control mb-3" onchange="changeLimit(this.value)">
        <option value="1" <?= $limit == 1 ? 'selected' : '' ?>>1</option>
        <option value="5" <?= $limit == 5 ? 'selected' : '' ?>>5</option>
        <option value="10" <?= $limit == 10 ? 'selected' : '' ?>>10</option>
        <option value="15" <?= $limit == 15 ? 'selected' : '' ?>>15</option>
    </select>

    <!-- search bar  -->
    <div class="card p-4">
        <input type="text" id="searchDepartment" class="form-control mb-3" placeholder="Search department">

        <form id="addDepartmentForm" class="mb-3">
            <div class="input-group">
                <input type="text" name="department_name" class="form-control" placeholder="Enter department name" required>
 <button type="submit" class="btn btn-custom">Add</button>
            </div>
        </form>

        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Department Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="departmentTable">
    <?php $counter = $offset + 1; while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $counter++; ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="editDepartment(<?php echo $row['id']; ?>, <?php echo json_encode($row['name']); ?>)">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deleteDepartment(<?php echo $row['id']; ?>)">Delete</button>
            </td>
        </tr>
    <?php endwhile; ?>
</tbody>
        </table>

        <!-- Pagination -->
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page - 1 ?>&limit=<?= $limit ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&limit=<?= $limit ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page + 1 ?>&limit=<?= $limit ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<script>
    $(document).ready(function() {
        // Live search
        $("#searchDepartment").on("keyup", function() {
            let searchText = $(this).val();
            $.get("", { search: searchText }, function(response) {
                let departments = JSON.parse(response);
                let html = "";
                let counter = 1;

                if (departments.length === 0) {
                    html = `<tr><td colspan="3" class="text-center text-danger">No results found</td></tr>`;
                } else {
                    departments.forEach(function(dept) {
                        html += `<tr>
                            <td>${counter++}</td>
                            <td>${dept.name}</td>
                            <td>
                                <button class="btn btn-warning btn-sm" onclick="editDepartment(${dept.id}, '${encodeURIComponent(dept.name)}')">Edit</button>
                                <button class="btn btn-danger btn-sm" onclick="deleteDepartment(${dept.id})">Delete</button>
                            </td>
                        </tr>`;
                    });
                }
                $("#departmentTable").html(html);
            });
        });

        // Add Department
        $("#addDepartmentForm").on("submit", function(event) {
            event.preventDefault();
            let formData = new FormData(this);
            formData.append("add_department", true);

            $.ajax({
                url: "",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    let res = JSON.parse(response);
                    showMessage(res.status, res.message);
                    if (res.status === "success") {
                        $("#addDepartmentForm")[0].reset();
                        loadDepartments(); // Refresh table without reloading page
                    }
                }
            });
        });
    });

    // Edit Department
    function editDepartment(id, name) {
    let newName = prompt("Edit Department Name:", name);
    if (newName !== null && newName.trim() !== "") {
        $.post("", { edit_department: true, department_id: id, department_name: newName }, function(response) {
            let res = JSON.parse(response);
            showMessage(res.status, res.message);
            if (res.status === "success") {
                loadDepartments(); // Refresh without page reload
            }
        });
    }
}

    // Delete Department
    function deleteDepartment(id) {
        if (confirm("Are you sure?")) {
            $.get("", { delete: id }, function(response) {
                let res = JSON.parse(response);
                showMessage(res.status, res.message);
                if (res.status === "success") {
                    loadDepartments(); // Refresh table without reloading
                }
            });
        }
    }

    // Refresh department table dynamically
    function loadDepartments() {
        $.get("", { search: "" }, function(response) {
            let departments = JSON.parse(response);
            let html = "";
            let counter = 1;

            if (departments.length === 0) {
                html = `<tr><td colspan="3" class="text-center text-danger">No departments found</td></tr>`;
            } else {
                departments.forEach(function(dept) {
                    html += `<tr>
                        <td>${counter++}</td>
                        <td>${dept.name}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editDepartment(${dept.id}, '${encodeURIComponent(dept.name)}')">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteDepartment(${dept.id})">Delete</button>
                        </td>
                    </tr>`;
                });
            }
            $("#departmentTable").html(html);
        });
    }

    // Show success/error message
    function showMessage(status, message) {
        $("#message").removeClass("d-none alert-success alert-danger")
            .addClass("alert-" + (status === "success" ? "success" : "danger"))
            .text(message);
        setTimeout(() => $("#message").addClass("d-none"), 3000);
    }

    function changeLimit(limit) {
        window.location.href = "?limit=" + limit + "&page=1"; // Reset to first page
    }
</script>

<!-- Scripts -->
<script>
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        function toggleDropdown(event, id) {
            event.preventDefault();
            var dropdown = document.getElementById(id);
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
    
</body>
</html> 
