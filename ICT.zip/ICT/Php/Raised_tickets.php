<?php
session_start();
require_once 'connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

if (!isset($_SESSION['user_email'])) {
    header("Location: ../index.php");
    exit();
}

$filter = isset($_POST['filter']) ? $_POST['filter'] : '';
$search_term = isset($_POST['search_term']) ? $_POST['search_term'] : '';

$sql = "SELECT id, ticket_number, description, status, priority, created_at, reported_by FROM tickets WHERE 1";

if ($filter && $search_term) {
    switch ($filter) {
        case 'ticket_number':
            $sql .= " AND ticket_number LIKE ?";
            break;
        case 'status':
            $sql .= " AND status LIKE ?";
            break;
        case 'priority':
            $sql .= " AND priority LIKE ?";
            break;
    }
}

$sql .= " ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if ($filter && $search_term) {
    $search_term = "%" . $search_term . "%";
    $stmt->bind_param("s", $search_term);
}
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Error executing query: " . $conn->error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_ticket'])) {
    $ticket_id = $_POST['ticket_id'];
    $new_status = $_POST['status'];
    $new_priority = $_POST['priority'];

    $user_query = "SELECT reported_by, ticket_number FROM tickets WHERE id = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $stmt->bind_result($reported_by, $ticket_number);
    $stmt->fetch();
    $stmt->close();

    $update_sql = "UPDATE tickets SET status = ?, priority = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssi", $new_status, $new_priority, $ticket_id);

    if ($stmt->execute()) {
        $message = "Ticket updated successfully!";
        $subject = "Ticket Update: $ticket_number";
        $body = "Your ticket (Ticket Number: $ticket_number) has been updated to status: $new_status with priority: $new_priority.";

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mlelwaimma99@gmail.com';
            $mail->Password = 'haxu ddpx szus blnx';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('mlelwaimma99@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($reported_by);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;

            $mail->send();
        } catch (Exception $e) {
            $message .= " But email notification failed: " . $mail->ErrorInfo;
        }
    } else {
        $message = "Error updating ticket!";
    }
    $stmt->close();
    header("Location: Raised_tickets.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Manage Tickets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="adminstyles.css">
    <style>
    body {
        background-color: #f8f9fa;
        font-family: 'Arial', sans-serif;
    }
    .container {
        margin-top: 8%;
    }
    .card {
        border-radius: 10px;
    }
    .table {
        background: white;
        border-radius: 10px;
        overflow: hidden;
        border: 1px solid #dee2e6;
    }
    th, td {
        border: 1px solid #dee2e6;
        text-align: center;
        padding: 10px;
    }
    th {
        background: #007bff;
        color: white;
    }
    .button-group {
        display: flex;
        justify-content: center; /* Center the buttons */
        gap: 5px; /* Space between buttons */
    }
    .update-btn, .view-btn {
        padding: 5px 10px;
        border-radius: 5px;
        cursor: pointer;
    }
    .update-btn {
        background-color: #ffc107;
        color: white;
        border: none;
    }
    .update-btn:hover {
        background-color: #e0a800;
    }
    .view-btn {
        background-color: #28a745;
        color: white;
        border: none;
        text-decoration: none;
    }
    .view-btn:hover {
        background-color: #218838;
    }
    .status-badge {
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 14px;
    }
    .status-Open { background: green; color: white; }
    .status-InProgress { background: orange; color: white; }
    .status-Resolved { background: orange; color: white; }
    .status-Closed { background: red; color: white; }
</style>
</head>
<body>

<?php include 'adminheader.php'; ?>
<?php include 'adminsidebar.php'; ?>

<div class="container">
    <div class="card shadow p-4">
        <h4 class="text-center">All Raised Tickets (Sorted by Recent Activity)</h4>

        <form method="POST" class="d-flex justify-content-between mb-3">
            <div class="form-group">
                <label for="filter">Filter By:</label>
                <select name="filter" id="filter" class="form-select">
                    <option value="">Select Filter</option>
                    <option value="ticket_number" <?= $filter == 'ticket_number' ? 'selected' : ''; ?>>Ticket Number</option>
                    <option value="status" <?= $filter == 'status' ? 'selected' : ''; ?>>Status</option>
                    <option value="priority" <?= $filter == 'priority' ? 'selected' : ''; ?>>Priority</option>
                </select>
            </div>

            <div class="form-group">
                <label for="search_term">Search:</label>
                <input type="text" name="search_term" id="search_term" class="form-control" value="<?= htmlspecialchars($search_term); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Apply Filter</button>
        </form>

        <?php if (!empty($message)) echo "<p class='text-success text-center'>$message</p>"; ?>

        <table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>#</th>
            <th>Ticket Number</th>
            <th>Description</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Reported Time</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $counter = 1;
        while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td class="text-center"><?= $counter++ ?></td>
            <td class="text-center"><?= htmlspecialchars($row['ticket_number']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td class="text-center">
                <span class="status-badge status-<?= str_replace(' ', '', $row['status']); ?>">
                    <?= htmlspecialchars($row['status']) ?>
                </span>
            </td>
            <td class="text-center"><?= htmlspecialchars($row['priority']) ?></td>
            <td class="text-center"><?= date("d M Y H:i", strtotime($row['created_at'])) ?></td>
            <td class="text-center">
                <div class="button-group">
                    <a href="view_ticketdetails.php?ticket_number=<?= urlencode($row['ticket_number']) ?>" class="view-btn">View Ticket</a>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="ticket_id" value="<?= $row['id'] ?>">
                        <select name="status" class="form-select d-inline w-auto">
                            <option value="Open" <?= ($row['status'] == 'Open') ? 'selected' : ''; ?>>Open</option>
                            <option value="In Progress" <?= ($row['status'] == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                            <option value="Closed" <?= ($row['status'] == 'closed') ? 'selected' : ''; ?>>Closed</option>
                        </select>
                        <select name="priority" class="form-select d-inline w-auto">
                            <option value="Low" <?= ($row['priority'] == 'Low') ? 'selected' : ''; ?>>Low</option>
                            <option value="Medium" <?= ($row['priority'] == 'Medium') ? ' selected' : ''; ?>>Medium</option>
                            <option value="High" <?= ($row['priority'] == 'High') ? 'selected' : ''; ?>>High</option>
                        </select>
                        <button type="submit" name="update_ticket" class="update-btn">Update</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>
    </div>
</div>

</body>
</html>

<?php
$conn->close();
?>