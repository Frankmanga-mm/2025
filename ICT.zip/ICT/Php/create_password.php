<?php
// Include the database connection
include "connection.php";

if (isset($_GET['email'])) {
    $email = $_GET['email'];
    
    // Check if the email exists in the database
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    if (!$user) {
        echo "Invalid user.";
        exit;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        // Check if passwords match
        if ($password === $confirm_password) {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Update the password and set status to 'active'
            $update_query = "UPDATE users SET password = '$hashed_password', status = 'active' WHERE email = '$email'";
            if (mysqli_query($conn, $update_query)) {
                // Redirect to index.php after successful password update
                header("Location: ../index.php");
                exit; // Ensure no further code is executed after redirection
            } else {
                echo '<p style="color: red; text-align: center;">Error updating password: ' . mysqli_error($conn) . '</p>';
            }
        } else {
            echo '<p style="color: red; text-align: center;">Passwords do not match!</p>';
        }
    }
} else {
    echo '<p style="color: red; text-align: center;">Invalid email link.</p>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Password</title>
    <!-- Bootstrap 5.3.0 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f7fa;
            padding-top: 80px;
        }
        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .form-container h3 {
            margin-bottom: 30px;
            color: #4CAF50;
            text-align: center;
        }
        .form-control {
            border-radius: 5px;
            box-shadow: none;
            font-size: 16px;
        }
        .btn-primary {
            background-color: #4CAF50;
            border-color: #4CAF50;
        }
        .btn-primary:hover {
            background-color: #45a049;
            border-color: #45a049;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .alert {
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4 form-container">
            <h3>Create Your Password</h3>

            <?php
                // Display any alert messages (success/error)
                if (isset($message)) {
                    echo '<div class="alert alert-danger">' . $message . '</div>';
                }
            ?>

            <form action="" method="POST">
                <!-- Hidden email input for processing -->
                <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required placeholder="Enter your password">
                </div>

                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Confirm your password">
                </div>

                <button type="submit" class="btn btn-primary w-100">Set Password</button>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap 5.3.0 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
