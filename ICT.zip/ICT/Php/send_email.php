<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

include "connection.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form data
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $middle_name = mysqli_real_escape_string($conn, $_POST['middle_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department_id = mysqli_real_escape_string($conn, $_POST['department_id']);

    // Prepare and execute the SQL query to insert the new user into the database
    $query = "INSERT INTO users (first_name, middle_name, last_name, email, department_id) 
              VALUES ('$first_name', '$middle_name', '$last_name', '$email', '$department_id')";

    if (mysqli_query($conn, $query)) {
        // Send the email with a simple message after inserting into the database
        $mail = new PHPMailer(true); // Set true for exceptions

        try {
            // Server settings for Gmail SMTP
            $mail->SMTPDebug = SMTP::DEBUG_SERVER; // For debugging, check SMTP logs
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // SMTP server
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'mangafrank20@gmail.com'; // SMTP username (use your Gmail username)
            $mail->Password = 'zbhx zgjk plhg lgzo'; // SMTP password (use your App Password here)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port = 587; // TCP port to connect to

            // Recipients
            $mail->setFrom('mangafrank20@gmail.com', 'ICT-Incident-Reporting-System');
            $mail->addAddress($email); // Add recipient email

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'Habari Mpendwa';
            $mail->Body = "Habari mpendwa $first_name,<br><br>Just wanted to say hello!";

            // Send email
            $mail->send();
            echo '<p style="color: green; text-align: center;">Message has been sent to the email address provided.</p>';
        } catch (Exception $e) {
            echo '<p style="color: red; text-align: center;">Message could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</p>';
        }

        // If insertion is successful, redirect to manage users page
        echo '<script>alert("User added successfully!"); window.location.href="manage_users.php";</script>';
    } else {
        // If insertion fails, display an error message
        echo '<p style="color: red;">Error: ' . mysqli_error($conn) . '</p>';
    }
}
?>
