<!-- includes/sidebar.php -->
<nav class="sidebar">
    <ul class="nav flex-column">

    <li class="nav-item">
            <a class="nav-link" href="admin.php">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="Raised_tickets.php">Tickets raised</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="reports.php">Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="manage_users.php">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="manage_departments.php">Manage Departments</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" onclick="toggleDropdown(event, 'settingsMenu')">Ticket Settings &#9662;</a>
            <div class="dropdown-container" id="settingsMenu">
                <a href="manage_categories.php"> Categories</a>
                <a href="manage_ticket_statuses.php">Ticket Statuses</a>
                <a href="manage_priority.php">Ticket Priority</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="changepasssword.php">Edit Profile</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-danger" href="logout.php">Logout</a>
        </li>
    </ul>
</nav>
